package es.pascual.exceptions;

public class IngredienteNoValidoExcepcion extends RuntimeException {

    public IngredienteNoValidoExcepcion(String message) {
        super(message);
    }
}
