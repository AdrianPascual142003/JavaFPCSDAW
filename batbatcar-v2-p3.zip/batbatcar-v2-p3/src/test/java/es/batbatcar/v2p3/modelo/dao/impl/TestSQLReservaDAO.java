package es.batbatcar.v2p3.modelo.dao.impl;

import es.batbatcar.v2p3.exceptions.ReservaNotFoundException;
import es.batbatcar.v2p3.modelo.dto.Reserva;
import es.batbatcar.v2p3.utils.database.MySQLConnection;
import org.dbunit.database.DatabaseConfig;
import org.dbunit.database.DatabaseConnection;
import org.dbunit.database.IDatabaseConnection;
import org.dbunit.dataset.xml.FlatXmlDataSet;
import org.dbunit.dataset.xml.FlatXmlDataSetBuilder;
import org.dbunit.ext.mysql.MySqlDataTypeFactory;
import org.dbunit.operation.DatabaseOperation;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.Set;
import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
public class TestSQLReservaDAO {

    @Autowired
    private SQLReservaDAO dbReservaDAO;

    @Autowired
    private MySQLConnection mySQLConnection;

    @BeforeEach
    public void restartDatabase() throws Exception {
        IDatabaseConnection connection = new DatabaseConnection(mySQLConnection.getConnection());
        connection.getConfig().setProperty(DatabaseConfig.PROPERTY_DATATYPE_FACTORY, new MySqlDataTypeFactory());
        DatabaseOperation.CLEAN_INSERT.execute(connection, getDataSet());
    }

    protected FlatXmlDataSet getDataSet() throws Exception {
        return new FlatXmlDataSetBuilder().setDtdMetadata(false).build(getClass().getResourceAsStream("/dataset/viajes.xml"));
    }

    @Test
    public void testFindAll() {
        Set<Reserva> reservas = dbReservaDAO.findAll();
        assertEquals(4, reservas.size());
    }

    @Test
    public void testFindById() {
        Reserva reserva = dbReservaDAO.findById("1-1");
        assertNotNull(reserva);
        Reserva reserva2 = dbReservaDAO.findById("2-1");
        assertNotNull(reserva2);
        Reserva reserva3 = dbReservaDAO.findById("0-1");
        assertNull(reserva3);
    }

    @Test
    public void testFindByUser() {
        ArrayList<Reserva> reservasUsuario = dbReservaDAO.findByUser("manolo");
        assertEquals(reservasUsuario.size(), 0);

        ArrayList<Reserva> reservasUsuario2 = dbReservaDAO.findByUser("alex");
        assertEquals(reservasUsuario2.size(), 1);

        ArrayList<Reserva> reservasUsuario3 = dbReservaDAO.findByUser("roberto");
        assertEquals(reservasUsuario3.size(), 2);
    }

    @Test
    public void testFindByTravel() {
        ArrayList<Reserva> reservasViaje1 = dbReservaDAO.findByTravel("1");
        assertEquals(reservasViaje1.size(), 2);
        ArrayList<Reserva> reservasViaje2 = dbReservaDAO.findByTravel("2");
        assertEquals(reservasViaje2.size(), 2);
        ArrayList<Reserva> reservasViaje3 = dbReservaDAO.findByTravel("3");
        assertEquals(reservasViaje3.size(), 0);
    }

    @Test
    public void testGetById() {
        try {
            String codReserva = "1-1";
            Reserva reserva = dbReservaDAO.getById(codReserva);
            assertEquals(codReserva, reserva.getCodigoReserva());
        } catch(ReservaNotFoundException ex) {
            fail();
        }
        assertThrows(ReservaNotFoundException.class, () -> {
            String codReserva = "0-1";
            dbReservaDAO.getById(codReserva);
        });
    }

    @Test
    public void testSaveInsert() {
        String codigoTest = "3-0";
        String usuarioTest = "usuarioTest";
        int plazasSolicitadas = 10;
        dbReservaDAO.save(new Reserva(codigoTest, usuarioTest, plazasSolicitadas));
        Reserva reserva2 = dbReservaDAO.findById(codigoTest);
        assertNotNull(reserva2);
        assertEquals(plazasSolicitadas, reserva2.getPlazasSolicitadas());
        assertEquals(usuarioTest, reserva2.getUsuario());
    }

    @Test
    public void testSaveUpdate() {
        String codigoTest = "2-2";
        int nuevasPlazasSolicitadas = 6;
        String nuevoUsuario = "Batoi";
        Reserva reserva = new Reserva("2-2", nuevoUsuario, nuevasPlazasSolicitadas, LocalDateTime.now());
        dbReservaDAO.save(reserva);
        Reserva reserva3 = dbReservaDAO.findById(codigoTest);
        assertNotNull(reserva3);
        assertEquals(nuevasPlazasSolicitadas, reserva3.getPlazasSolicitadas());
        assertEquals(nuevoUsuario, reserva3.getUsuario());
    }

    @Test
    public void testRemove() {
        String codigoTest = "2-1";
        dbReservaDAO.remove(new Reserva(codigoTest));
        Reserva reserva2 = dbReservaDAO.findById(codigoTest);
        assertNull(reserva2);
    }
}
