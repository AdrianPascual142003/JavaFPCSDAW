package es.batbatcar.v2p3.modelo.dao.utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class TestFileGenericDAO {

    protected static void prepareTestDBFile(String testFilePath, String[] initialRegisters) {
        try {
            File file = new File(TestFileGenericDAO.class.getResource(testFilePath).getFile());
            try (BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file, false))) {
                for (String registerReserva: initialRegisters) {
                    bufferedWriter.write(registerReserva);
                    bufferedWriter.newLine();
                }
            }
        }catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
    }

}
