package es.batbatcar.v2p3.modelo.dao.impl;

import es.batbatcar.v2p3.exceptions.ViajeNotFoundException;
import es.batbatcar.v2p3.modelo.dao.IViajeDAO;
import es.batbatcar.v2p3.modelo.dto.types.*;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Set;
import java.util.TreeSet;

@Service("FileViajeDAO")
public class FileViajeDAO extends FileGenericDAO<Viaje> implements IViajeDAO {

    private static final String DATABASE_FILE = "/database/viajes.txt";
    private static final int COLUM_TIPO = 0;
    private static final int COLUMN_COD = 1;
    private static final int COLUMN_PROPIETARIO = 2;
    private static final int COLUMN_RUTA = 3;
    private static final int COLUMN_FECHA = 4;
    private static final int COLUMN_DURACION = 5;
    private static final int COLUMN_PRECIO = 6;
    private static final int COLUMN_PLAZAS = 7;
    private static final int COLUMN_ESTADO = 8;

    public FileViajeDAO() {
        this(DATABASE_FILE);
    }

    public FileViajeDAO(String pathToFile) {
        super(pathToFile);
    }

    protected String getRegisterFromEntity(Viaje viaje) {
        String[] fields = new String[9];
        fields[COLUM_TIPO] = viaje.getTypoString().toUpperCase().replace(" ","");
        fields[COLUMN_COD] = String.valueOf(viaje.getCodViaje());
        fields[COLUMN_PROPIETARIO] = viaje.getPropietario();
        fields[COLUMN_RUTA] =  viaje.getRuta();
        fields[COLUMN_FECHA] =  viaje.getFechaSalidaFormatted();
        fields[COLUMN_DURACION] =  String.valueOf(viaje.getDuracion());
        fields[COLUMN_PRECIO] =  String.valueOf(viaje.getPrecio());
        fields[COLUMN_PLAZAS] =  String.valueOf(viaje.getPlazasOfertadas());
        fields[COLUMN_ESTADO] =  viaje.getEstado().toString();
        return String.join(FIELD_SEPARATOR, fields);
    }

    protected Viaje getEntityFromRegister(String viajeRegistro) {
        String[] viajeFields = viajeRegistro.split(FIELD_SEPARATOR);
        String tipoViaje = viajeFields[COLUM_TIPO];
        int codViaje = Integer.parseInt(viajeFields[COLUMN_COD]);
        String propietario = viajeFields[COLUMN_PROPIETARIO];
        String ruta = viajeFields[COLUMN_RUTA];
        LocalDateTime fechaDeSalida = LocalDateTime.parse(viajeFields[COLUMN_FECHA], DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        int duracion = Integer.parseInt(viajeFields[COLUMN_DURACION]);
        float precio = Float.parseFloat(viajeFields[COLUMN_PRECIO]);
        int numPlazas = Integer.parseInt(viajeFields[COLUMN_PLAZAS]);
        EstadoViaje estadoViaje = EstadoViaje.parse(viajeFields[COLUMN_ESTADO]);
        return getViajeOfType(tipoViaje, codViaje, propietario, ruta, fechaDeSalida, duracion, precio, numPlazas, estadoViaje);
    }

    private Viaje getViajeOfType(String tipoViaje, int codViaje, String propietario, String ruta,
                                 LocalDateTime fechaDeSalida, int duracion, float precio, int numPlazas, EstadoViaje estadoViaje) {
        if (tipoViaje.equals("VIAJE")) {
            return new Viaje(codViaje, propietario, ruta, fechaDeSalida, duracion, precio, numPlazas, estadoViaje);
        } else if (tipoViaje.equals("VIAJEFLEXIBLE")) {
            return new ViajeFlexible(codViaje, propietario, ruta, fechaDeSalida, duracion, precio, numPlazas, estadoViaje);
        } else if (tipoViaje.equals("VIAJEEXCLUSIVO")) {
            return new ViajeExclusivo(codViaje, propietario, ruta, fechaDeSalida, duracion, precio, numPlazas, estadoViaje);
        } else if (tipoViaje.equals("VIAJECANCELABLE")) {
            return new ViajeCancelable(codViaje, propietario, ruta, fechaDeSalida, duracion, precio, numPlazas, estadoViaje);
        } else {
            return null;
        }
    }

    @Override
    public Set<Viaje> findAll(String city) {
        Set<Viaje> viajesFiltrados = new TreeSet<>();
        Set<Viaje> todosViajes = findAll();
        for (Viaje viaje: todosViajes) {
            if (viaje.tieneEsteCiudadDestino(city)) {
                viajesFiltrados.add(viaje);
            }
        }
        return viajesFiltrados;
    }

    @Override
    public Set<Viaje> findAll(EstadoViaje estadoViaje) {
        Set<Viaje> viajesFiltrados = new TreeSet<>();
        Set<Viaje> todosViajes = findAll();
        for (Viaje viaje: todosViajes) {
            if (viaje.tieneEsteEstado(estadoViaje)) {
                viajesFiltrados.add(viaje);
            }
        }
        return viajesFiltrados;
    }

    @Override
    public Set<Viaje> findAll(Class<? extends Viaje> viajeClass) {
        Set<Viaje> viajesFiltrados = new TreeSet<>();
        Set<Viaje> todosViajes = findAll();
        for (Viaje viaje: todosViajes) {
            if (viaje.getClass() == viajeClass) {
                viajesFiltrados.add(viaje);
            }
        }
        return viajesFiltrados;
    }

    @Override
    public Viaje getById(int codViaje) throws ViajeNotFoundException{
        Viaje viaje = findById(codViaje);
        if (viaje == null) {
            throw new ViajeNotFoundException(codViaje);
        }
        return viaje;
    }

    @Override
    public Viaje findById(int codViaje) {
         return super.findById(String.valueOf(codViaje));
    }

}
