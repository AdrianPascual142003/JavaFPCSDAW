package es.batbatcar.v2p3.modelo.dao;

import es.batbatcar.v2p3.exceptions.ViajeNotFoundException;
import es.batbatcar.v2p3.modelo.dto.types.EstadoViaje;
import es.batbatcar.v2p3.modelo.dto.types.Viaje;

import java.util.Set;

public interface IViajeDAO {

    /**
     * Obtiene todos los viajes
     *
     * @return
     */
    Set<Viaje> findAll();

    /**
     * Obtiene todos los viajes con destino a @city
     *
     * @return
     */
    Set<Viaje> findAll(String city);

    /**
     * Obtiene todos los viajes con el estado @estadoViaje
     *
     * @return
     */
    Set<Viaje> findAll(EstadoViaje estadoViaje);

    /**
     * Obtiene todos los viajes de @Class
     *
     * @return
     */
    Set<Viaje> findAll(Class<? extends Viaje> viajeClass);

    /**
     * Obtiene el viaje cuyo codigo es @codViaje
     *
     * @return Viaje or null
     */
    Viaje findById(int codViaje);

    /**
     * Obtiene el viaje cuyo codigo es @codViaje
     *
     * @return Viaje or throws and Exception
     */
    Viaje getById(int codViaje) throws ViajeNotFoundException;

    /**
     * Guarda o actualiza @viaje
     *
     * @param viaje
     * @return true if @viaje ha sido guardado o actualizado
     */
    boolean save(Viaje viaje);

    /**
     * Elimina el viaje @viaje
     *
     * @param viaje
     * @return true if @viaje has been removed
     */
    boolean remove(Viaje viaje);

}
