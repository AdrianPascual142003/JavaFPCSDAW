package es.batbatcar.v2p3.modelo.dao.impl;


import es.batbatcar.v2p3.exceptions.DatabaseConnectionException;
import es.batbatcar.v2p3.exceptions.ViajeNotCreatedException;
import es.batbatcar.v2p3.exceptions.ViajeNotFoundException;
import es.batbatcar.v2p3.modelo.dao.IViajeDAO;
import es.batbatcar.v2p3.modelo.dto.types.*;
import es.batbatcar.v2p3.utils.database.MySQLConnection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

@Service
public class SQLViajeDAO implements IViajeDAO {

    private final MySQLConnection mySQLConnection;

    public SQLViajeDAO(@Autowired MySQLConnection mySQLConnection) {
        this.mySQLConnection = mySQLConnection;
    }

    @Override
    public Set<Viaje> findAll() {
        Connection connection = mySQLConnection.getConnection();
        String sql = "SELECT * from viajes";
        Set<Viaje> viajes =  new HashSet<>();
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                viajes.add(mapToEntity(rs));
            }
            return viajes;
        } catch (SQLException e) {
            throw new DatabaseConnectionException(e.getMessage());
        }
    }

    @Override
    public Set<Viaje> findAll(String city) {
        Connection connection = mySQLConnection.getConnection();
        String sql = "SELECT * from viajes where ruta like ?";
        Set<Viaje> viajes =  new HashSet<>();
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1,"%-" + city + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                viajes.add(mapToEntity(rs));
            }
            return viajes;
        } catch (SQLException e) {
            throw new DatabaseConnectionException(e.getMessage());
        }
    }

    @Override
    public Set<Viaje> findAll(EstadoViaje estadoViaje) {
        Connection connection = mySQLConnection.getConnection();
        String sql = "SELECT * from viajes where estadoViaje like ?";
        Set<Viaje> viajes =  new HashSet<>();
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, estadoViaje.toString());
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                viajes.add(mapToEntity(rs));
            }
            return viajes;
        } catch (SQLException e) {
            throw new DatabaseConnectionException(e.getMessage());
        }
    }

    @Override
    public Set<Viaje> findAll(Class<? extends Viaje> viajeClass) {
        Connection connection = mySQLConnection.getConnection();
        String sql = "SELECT * from viajes where tipo = ?";
        Set<Viaje> viajes = new HashSet<>();
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            String nombreClase = nameClass(viajeClass);
            System.out.println(nombreClase);
            ps.setString(1, nombreClase);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                viajes.add(mapToEntity(rs));
            }
            return viajes;
        } catch (SQLException e) {
            throw new DatabaseConnectionException(e.getMessage());
        }
    }

    private String nameClass(Class<? extends Viaje> viajeClass) {
        String nombreClase = viajeClass.getSimpleName().toUpperCase();
        if (nombreClase.equals("VIAJE")) {
            return nombreClase;
        }
        nombreClase = nombreClase.replace("VIAJE","");
        return nombreClase;
    }

    @Override
    public Viaje findById(int codViaje) {
        Connection connection = mySQLConnection.getConnection();
        String sql = "SELECT * from viajes where codViaje = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, codViaje);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return mapToEntity(rs);
            }
            return null;
        } catch (SQLException e) {
            throw new DatabaseConnectionException(e.getMessage());
        }
    }

    @Override
    public Viaje getById(int codViaje) throws ViajeNotFoundException {
        Viaje viaje = findById(codViaje);
        if (viaje == null) {
            throw new ViajeNotFoundException("No se ha encontrado el viaje");
        }
        return viaje;
    }

    @Override
    public boolean save(Viaje viaje) {
        if (findById(viaje.getCodViaje()) == null) {
            return insert(viaje);
        }else {
            return update(viaje);
        }
    }

    private boolean update(Viaje viaje) {
        Connection connection = mySQLConnection.getConnection();
        String sql = "UPDATE viajes set tipo = ?, propietario = ?, ruta = ?, fechaSalida = ?, duracion = ?, precio = ?, plazasOfertadas = ?, estadoViaje = ? where codViaje = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1,nameClass(viaje.getClass()));
            ps.setString(2,viaje.getPropietario());
            ps.setString(3,viaje.getRuta());
            ps.setTimestamp(4,Timestamp.valueOf(viaje.getFechaSalida()));
            ps.setLong(5,viaje.getDuracion());
            ps.setFloat(6,viaje.getPrecio());
            ps.setInt(7,viaje.getPlazasOfertadas());
            ps.setString(8,viaje.getEstado().toString());
            ps.setInt(9, viaje.getCodViaje());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            throw new DatabaseConnectionException(e.getMessage());
        }
    }

    /*
     private boolean insert(Viaje viaje) {
        Connection connection = mySQLConnection.getConnection();
        String sql = "INSERT INTO viajes VALUES (?,?,?,?,?,?,?,?,?)";
        try (PreparedStatement ps = connection.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)) {
            ps.setNull(1, Types.INTEGER);
            ps.setString(2,nameClass(viaje.getClass()));
            ps.setString(3,viaje.getPropietario());
            ps.setString(4,viaje.getRuta());
            ps.setTimestamp(5,Timestamp.valueOf(viaje.getFechaSalida()));
            ps.setLong(6,viaje.getDuracion());
            ps.setFloat(7,viaje.getPrecio());
            ps.setInt(8,viaje.getPlazasOfertadas());
            ps.setString(9,viaje.getEstado().toString());
            ps.executeUpdate();
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                int codViaje = rs.getInt(1);
                viaje.setCodViaje(codViaje);
            }
            return true;
        } catch (SQLException e) {
            throw new DatabaseConnectionException(e.getMessage());
        }
    }
     */

    private boolean insert(Viaje viaje) {
        Connection connection = mySQLConnection.getConnection();
        String sql = "INSERT INTO viajes VALUES (?,?,?,?,?,?,?,?,?)";
        try (PreparedStatement ps = connection.prepareStatement(sql,Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, viaje.getCodViaje());
            ps.setString(2,nameClass(viaje.getClass()));
            ps.setString(3,viaje.getPropietario());
            ps.setString(4,viaje.getRuta());
            ps.setTimestamp(5,Timestamp.valueOf(viaje.getFechaSalida()));
            ps.setLong(6,viaje.getDuracion());
            ps.setFloat(7,viaje.getPrecio());
            ps.setInt(8,viaje.getPlazasOfertadas());
            ps.setString(9,viaje.getEstado().toString());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            throw new DatabaseConnectionException(e.getMessage());
        }
    }

    @Override
    public boolean remove(Viaje viaje) {
        Connection connection = mySQLConnection.getConnection();
        String sql = "DELETE FROM viajes where codViaje = ?" ;
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1,viaje.getCodViaje());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            throw new DatabaseConnectionException(e.getMessage());
        }
    }

    public Viaje mapToEntity(ResultSet rs) throws SQLException {
        int codViaje = rs.getInt("codViaje");
        String tipo = rs.getString("tipo");
        String propietario = rs.getString("propietario");
        String ruta = rs.getString("ruta");
        LocalDateTime fechaSalida = rs.getTimestamp("fechaSalida").toLocalDateTime();
        int duracion = rs.getInt("duracion");
        float precio = rs.getFloat("precio");
        int plazasOfertadas = rs.getInt("plazasOfertadas");
        EstadoViaje estadoViaje = EstadoViaje.valueOf(rs.getString("estadoViaje"));

        switch (tipo) {
            case "VIAJE":
                return new Viaje(codViaje,propietario,ruta,fechaSalida,duracion,precio,plazasOfertadas,estadoViaje);
            case "CANCELABLE":
                return new ViajeCancelable(codViaje,propietario,ruta,fechaSalida,duracion,precio,plazasOfertadas,estadoViaje);
            case "EXCLUSIVO":
                return new ViajeExclusivo(codViaje,propietario,ruta,fechaSalida,duracion,precio,plazasOfertadas,estadoViaje);
            case "FLEXIBLE":
                return new ViajeFlexible(codViaje,propietario,ruta,fechaSalida,duracion,precio,plazasOfertadas,estadoViaje);
            default:
                throw new RuntimeException("error");
        }
    }
}
