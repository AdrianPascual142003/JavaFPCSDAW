package es.batbatcar.v2p3.modelo.dao;

public interface IEntity {
    String getId();
}
