package es.batbatcar.v2p3.modelo.dto.types;

import es.batbatcar.v2p3.exceptions.ReservaNoCancelableException;
import es.batbatcar.v2p3.exceptions.ReservaNoModificableException;
import es.batbatcar.v2p3.exceptions.ReservaNoValidaException;
import es.batbatcar.v2p3.exceptions.ReservaPlazasNoDisponiblesException;
import es.batbatcar.v2p3.modelo.dto.Reserva;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class ViajeFlexible extends ViajeCancelable {

    public ViajeFlexible(int codViaje, String propietario, String ruta, LocalDateTime fechaSalida, long duracion) {
        super(codViaje, propietario, ruta, fechaSalida, duracion);
    }

    public ViajeFlexible(int codViaje, String propietario, String ruta, LocalDateTime fechaSalida, long duracion, float precio, int numPlazas) {
        super(codViaje, propietario, ruta, fechaSalida, duracion, precio, numPlazas);
    }

    public ViajeFlexible(int codViaje, String propietario, String ruta, LocalDateTime fechaSalida, long duracion, float precio, int numPlazas, EstadoViaje estadoViaje) {
        super(codViaje, propietario, ruta, fechaSalida, duracion, precio, numPlazas, estadoViaje);
    }

    public ViajeFlexible(int codViaje, String propietario, String ruta, LocalDateTime fechaSalida, long duracion, float precio, int numPlazas, EstadoViaje estadoViaje, ArrayList<Reserva> reservas) {
        super(codViaje, propietario, ruta, fechaSalida, duracion, precio, numPlazas, estadoViaje, reservas);
    }

    @Override
    public String getTypoString() {
        return "Viaje Flexible";
    }

    public Reserva modificarReserva(Reserva reserva, String usuario, int numPlazas) {
         if (haSalido()) {
            throw new ReservaNoCancelableException("La reserva no se puede modificar porque el viaje ya ha salido");
        }
        if (isCancelado()) {
            throw new ReservaNoCancelableException("La reserva no se puede modificar porque el viaje ya ha sido cancelado");
        }
        if (numPlazas > getPlazasDisponibles()) {
            throw new ReservaPlazasNoDisponiblesException("No se ha podido modificar la reserva");
        }
        reserva.setPlazasSolicitadas(numPlazas);
        if (getPlazasReservadas() == this.plazasOfertadas) {
            cerrarViaje();
        }
        return reserva;
    }

    @Override
    public boolean isModificable() {
        return true;
    }

}
