package es.batbatcar.v2p3.exceptions;

public class ReservaNoValidaException extends RuntimeException {

    public ReservaNoValidaException(String motivo) {
        super("No se ha podido realizar la reserva. Motivo: " + motivo);
    }
}


