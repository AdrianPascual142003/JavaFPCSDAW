package es.batbatcar.v2p3.utils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;

public class Validator {

    private static final String REGEXP_ROUTE = "^.+-.*";

    private static final String REGEXP_NUMERIC = "^\\d+(.\\d)*$";

    /**
     * string char length 1-45
     */
    private static final String SHORT_STRING = "^\\w{1,45}$";


    /**
     * Integer between 0-99
     */
    private static final String REGEXP_AGE = "^[0-9]{1,2}$";

    public static boolean isValidRoute(String ruta){
        return ruta.matches(REGEXP_ROUTE);
    }

    public static boolean isNumeric(String numberString){
        return numberString.matches(REGEXP_NUMERIC);
    }

    public static boolean validateShortString(String name){
        return name.matches(SHORT_STRING);
    }

    public static boolean validateLength(String param, int min, int max){
        return param.length() >= min  && param.length() <= max;
    }

    public static boolean isValidDateTime(String dateTime) {
        try {
            LocalDate.parse(dateTime, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
        } catch (DateTimeParseException e) {
            return false;
        }
        return true;
    }
    public static boolean isValidDate(String date) {
        try {
            LocalDate.parse(date, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        } catch (DateTimeParseException e) {
            return false;
        }
        return true;
    }

    public static boolean isValidTime(String time) {
        try {
            LocalDate.parse(time, DateTimeFormatter.ofPattern("HH:mm"));
        } catch (DateTimeParseException e) {
            return false;
        }
        return true;
    }

}

