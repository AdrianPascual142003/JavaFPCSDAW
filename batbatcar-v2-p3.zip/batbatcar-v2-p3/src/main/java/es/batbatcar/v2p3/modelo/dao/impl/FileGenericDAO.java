package es.batbatcar.v2p3.modelo.dao.impl;

import es.batbatcar.v2p3.exceptions.DatabaseConnectionException;
import es.batbatcar.v2p3.modelo.dao.IEntity;

import java.io.*;
import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

public abstract class FileGenericDAO <T> {

    public static final String FIELD_SEPARATOR = ";";

    private File file;

    public FileGenericDAO(String pathToFile) {
        this.file = new File(getClass().getResource(pathToFile).getFile());
    }

    public File getFile() {
        return file;
    }

    protected void append(T entity) throws IOException {
        try (BufferedWriter bufferedWriter = getWriter(true)) {
            bufferedWriter.write(getRegisterFromEntity(entity));
            bufferedWriter.newLine();
        }
    }

    protected boolean updateOrRemove(T entity, boolean update) throws IOException {
        Collection<T> entityList = findAll();
        try (BufferedWriter bufferedWriter = getWriter(false)) {
            for (T entityItem : entityList) {
                if (!entityItem.equals(entity)) {
                    bufferedWriter.write(getRegisterFromEntity(entityItem));
                    bufferedWriter.newLine();
                } else if (update) {
                    bufferedWriter.write(getRegisterFromEntity(entity));
                    bufferedWriter.newLine();
                }
            }
        }
        return true;
    }

    public T findById(String codReserva) {
        try (BufferedReader bufferedReader = getReader()) {
            do {
                String reservaRegistro = bufferedReader.readLine();
                if (reservaRegistro == null) {
                    return null;
                }
                T entity = getEntityFromRegister(reservaRegistro);
                if (((IEntity) entity).getId().equals(codReserva)){
                    return entity;
                }
            } while (true);
        } catch (IOException ex) {
            throw new DatabaseConnectionException(ex.getMessage());
        }
    }
    public boolean save(T entity) {
        try {
            if (findById(((IEntity) entity).getId()) == null) {
                append(entity);
                return true;
            }
            return updateOrRemove(entity, true);
        } catch (IOException ex) {
            throw new DatabaseConnectionException(ex.getMessage());
        }
    }

    public boolean remove(T entity) {
        try {
            if (findById(((IEntity) entity).getId()) == null) {
                return false;
            }
            return updateOrRemove(entity, false);
        } catch (IOException ex) {
            throw new DatabaseConnectionException(ex.getMessage());
        }
    }

    public Set<T> findAll() {
        try {
            Set<T> entity = new HashSet<>();
            try (BufferedReader bufferedReader = getReader()) {
                do {
                    String reservaRegistro = bufferedReader.readLine();
                    if (reservaRegistro == null) {
                        return entity;
                    }
                    entity.add(getEntityFromRegister(reservaRegistro));
                } while (true);
            }
        } catch (IOException ex) {
            throw new DatabaseConnectionException(ex.getMessage());
        }
    }

    protected BufferedWriter getWriter(boolean append) throws IOException {
        return  new BufferedWriter(new FileWriter(file, append));
    }

    protected BufferedReader getReader() throws IOException {
        return new BufferedReader(new FileReader(file));
    }

    protected abstract String getRegisterFromEntity(T entity);

    protected abstract T getEntityFromRegister(String register);


}
