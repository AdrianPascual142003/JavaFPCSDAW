package es.batbatcar.v2p3.exceptions;

public class InvalidCredentialsException extends Exception {

    public InvalidCredentialsException(String msg){
        super(msg);
    }

}
