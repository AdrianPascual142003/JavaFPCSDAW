package es.batbatcar.v2p3.controllers;
import es.batbatcar.v2p3.exceptions.*;
import es.batbatcar.v2p3.modelo.dao.impl.FileReservaDAO;
import es.batbatcar.v2p3.modelo.dao.impl.SQLReservaDAO;
import es.batbatcar.v2p3.modelo.dto.Reserva;
import es.batbatcar.v2p3.modelo.dto.types.Viaje;
import es.batbatcar.v2p3.modelo.repositories.ViajesRepository;
import es.batbatcar.v2p3.utils.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
public class ReservaController {

    /**
     * Con esta anotación, el framework buscará una clase decorada con la anotación @Service
     * que implemente esta interfaz indicada, creará un objeto de ella y la asignará de forma
     * automática a esta variable (inyección de dependencias). De esta forma la tendremos disponibles
     * en todos los recursos.
     */
    @Autowired
    private SQLReservaDAO reservaDAO;

    @Autowired
    private ViajesRepository viajesRepository;

    /**
     *  Muestra el formulario para añadir una reserva al viaje @codViaje
     */
    @GetMapping(value = "viaje/reserva/add")
    public String getAddReservaAction(@RequestParam String codViaje, Model modelFromView) {
        modelFromView.addAttribute("codViaje", codViaje);
        modelFromView.addAttribute("title", "Añadir Reserva");
        modelFromView.addAttribute("isView",false);
        modelFromView.addAttribute("isEditable",false);
        return "reserva/reserva_form";
    }

    /**
     *  Procesa el formulario completado por el usario para añadir una reserva al viaje @codViaje.
     *  Una vez procesado redirije al usuario al listado completo de reservas del viaje
     */
    @PostMapping(value = "viaje/reserva/add")
    public String postAddReservaAction(@RequestParam String codViaje,
                                       @RequestParam String usuario,
                                       RedirectAttributes redirectAttributes,
                                       @RequestParam int plazasSolicitadas) throws ViajeNotFoundException {
        String reservaCod = String.format("%s-%d", codViaje, reservaDAO.findByTravel(codViaje).size() + 1);
        redirectAttributes.addAttribute("codViaje", codViaje);
        Viaje viaje = viajesRepository.getViaje(Integer.parseInt(codViaje));
        HashMap<String, String> errors = new HashMap<>();
        if (plazasSolicitadas > viaje.getPlazasDisponibles()){
            errors.put("plazasSolicitadas", "No hay suficientes plazas en el viaje");
            redirectAttributes.addFlashAttribute("errors", errors);
            return "redirect:/viaje/reserva/add?codViaje=" + codViaje;
        }else {
            Reserva reserva = new Reserva(reservaCod, usuario, plazasSolicitadas);
            reservaDAO.save(reserva);
        }
        return "redirect:/viaje/reservas";
    }

    /**
     * Endpoint que nos permite visualizar el listado de todas las reservas del viaje @codViaje
     */
    @GetMapping(value = "viaje/reservas")
    public String getReservasAction(@RequestParam HashMap<String, String> params, Model modelFromView) {
        String codViaje = params.get("codViaje");
        if (codViaje == null || codViaje.isBlank()){
            return "redirect:/viajes";
        }
        List<Reserva> reservaList;
        String searchParams = params.get("search");
        if (searchParams != null) {
            reservaList = reservaDAO.findBySearchParams(codViaje, searchParams.trim());
        } else {
            reservaList = reservaDAO.findByTravel(codViaje);
        }
        modelFromView.addAttribute("codViaje", codViaje);
        modelFromView.addAttribute("reservas", reservaList);
        modelFromView.addAttribute("titulo", "Listado de reservas");
        return "reserva/listado";
    }

    /**
     * Endpoint que nos permite visualizar el listado de todas las reservas de un usuario
     */
    @GetMapping("viaje/reservas/user")
    public String getReservaUserAction(@RequestParam String usuario, Model modelFromView) {
        List<Reserva> reservaList = reservaDAO.findByUser(usuario);
        modelFromView.addAttribute("usuario", usuario);
        modelFromView.addAttribute("reservas", reservaList);
        modelFromView.addAttribute("titulo", "Listado de Reservas del usuario " + usuario);
        return "reserva/listado_usuario";
    }

    @GetMapping("viaje/reserva/details")
    public String getReservaDetailsAction(@RequestParam String codReserva, Model model) throws ReservaNotFoundException {
        Reserva reserva = reservaDAO.getById(codReserva);
        Viaje viaje = viajesRepository.getViajeConReserva(codReserva);
        if (viaje.estaDisponible()) {
            model.addAttribute("isMod",viaje.isModificable());
        }
        model.addAttribute("isView", true);
        model.addAttribute("reserva", reserva);
        return "reserva/reserva_form";
    }

    @PostMapping("viaje/reserva/cancelar")
    public String getReservaCancelableAction(@RequestParam String codReserva, RedirectAttributes redirectAttributes) throws ReservaNotFoundException {
        Viaje viaje = viajesRepository.getViajeConReserva(codReserva);
        Reserva reserva = viaje.getReserva(codReserva);
        Map<String, String> errors = new HashMap<>();
        try {
            viaje.cancelarReserva(reserva);
            reservaDAO.remove(reserva);
        } catch (ReservaNoCancelableException e) {
            errors.put("ReservaError", e.getMessage());
        }
        redirectAttributes.addFlashAttribute("errors", errors);
        return "redirect:/viaje?codViaje=" + viaje.getCodViaje();
    }

    @GetMapping("viaje/reserva/modificar")
    public String getReservaModificarAcction(@RequestParam String codReserva, Model model) throws ReservaNotFoundException {
        Reserva reserva = reservaDAO.getById(codReserva);
        model.addAttribute("reserva", reserva);
        model.addAttribute("isView", false);
        model.addAttribute("isEditable", true);
        return "reserva/reserva_modify_form";
    }

    @PostMapping("viaje/reserva/modificar")
    public String postReservaModificarAcction(@RequestParam String codReserva, int plazasSolicitadas , RedirectAttributes redirectAttributes) throws ReservaNotFoundException {
        Viaje viaje = viajesRepository.getViajeConReserva(codReserva);
        Reserva reserva = viaje.getReserva(codReserva);
        HashMap<String,String> errors = new HashMap<>();
        try {
            if (viaje.estaDisponible() && viaje.getPlazasDisponibles() > 0) {
                viaje.modificarReserva(reserva,reserva.getUsuario(),plazasSolicitadas);
                reservaDAO.save(reserva);
                return "redirect:/viajes";
            }
        }catch (ReservaPlazasNoDisponiblesException e) {
            errors.put("plazasSolicitadas", "No hay tantas plazas disponilbles");
        }
        redirectAttributes.addFlashAttribute("errors",errors);
        return "redirect:/viaje/reserva/modificar?codReserva="+codReserva;
    }

}
