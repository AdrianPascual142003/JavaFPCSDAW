package es.batbatcar.v2p3.exceptions;

public class ReservaPlazasNoDisponiblesException extends RuntimeException {
    public ReservaPlazasNoDisponiblesException(String s) {
        super(s);
    }
}
