package es.batbatcar.v2p3.exceptions;

public class InvalidEstadoViajeException extends RuntimeException {
    public InvalidEstadoViajeException() {
        super("El estado de viaje asignado es incorrecto");
    }
}
