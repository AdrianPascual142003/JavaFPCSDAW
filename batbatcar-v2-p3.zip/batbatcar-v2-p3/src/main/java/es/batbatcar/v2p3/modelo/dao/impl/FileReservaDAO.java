package es.batbatcar.v2p3.modelo.dao.impl;

import es.batbatcar.v2p3.exceptions.ReservaNotFoundException;
import es.batbatcar.v2p3.exceptions.DatabaseConnectionException;
import es.batbatcar.v2p3.modelo.dao.IReservaDAO;
import es.batbatcar.v2p3.modelo.dto.Reserva;
import org.springframework.stereotype.Service;

import java.io.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

@Service("FileReservaDao")
public class FileReservaDAO extends FileGenericDAO<Reserva> implements IReservaDAO {

    private static final String DATABASE_FILE = "/database/reservas.txt";

    private static final int COLUM_COD_RESERVA = 0;

    private static final int COLUMN_USUARIO = 1;

    private static final int COLUMN_PLAZAS = 2;

    private static final int COLUMN_FECHA_TIEMPO_REALIZACION = 3;

    public FileReservaDAO() {
        this(DATABASE_FILE);
    }

    public FileReservaDAO(String pathToFile) {
        super(pathToFile);
    }

    @Override
    public ArrayList<Reserva> findByUser(String user) {
        try {
            ArrayList<Reserva> reservas = new ArrayList<>();
            try (BufferedReader bufferedReader = getReader()) {
                do {
                    String reservaRegistro = bufferedReader.readLine();
                    if (reservaRegistro == null) {
                        return reservas;
                    }
                    Reserva reserva = getEntityFromRegister(reservaRegistro);
                    if (reserva.getUsuario().equals(user)) {
                        reservas.add(reserva);
                    }
                } while (true);
            }
        } catch (IOException ex) {
            throw new DatabaseConnectionException(ex.getMessage());
        }
    }

    @Override
    public ArrayList<Reserva> findByTravel(String codViaje) {
        try {
            ArrayList<Reserva> reservas = new ArrayList<>();
            try (BufferedReader bufferedReader = getReader()) {
                do {
                    String reservaRegistro = bufferedReader.readLine();
                    if (reservaRegistro == null) {
                        return reservas;
                    }
                    Reserva reserva = getEntityFromRegister(reservaRegistro);
                    if (reserva.perteneceAlViaje(codViaje)) {
                        reservas.add(reserva);
                    }
                } while (true);
            }
        } catch(IOException ex) {
            throw new DatabaseConnectionException(ex.getMessage());
        }
    }

    @Override
    public Reserva getById(String codReserva) throws ReservaNotFoundException {
        Reserva reservaBuscada = findById(codReserva);
        if (reservaBuscada == null) {
            throw new ReservaNotFoundException(codReserva);
        }
        return reservaBuscada;
    }

    @Override
    public List<Reserva> findBySearchParams(String codViaje, String searchParams) {
        List<Reserva> reservasList = findByTravel(codViaje);
        List<Reserva> reservasBuscadas = new ArrayList<>();
        for (Reserva reserva: reservasList) {
            if (reserva.getUsuario().toLowerCase().contains(searchParams.toLowerCase())
                    || reserva.getCodigoReserva().contains(searchParams)) {
                reservasBuscadas.add(reserva);
            }
        }
        return reservasBuscadas;
    }

    @Override
    protected String getRegisterFromEntity(Reserva entity) {
        String[] fields = new String[4];
        fields[COLUM_COD_RESERVA] = entity.getCodigoReserva().trim();
        fields[COLUMN_USUARIO] = entity.getUsuario().trim();
        fields[COLUMN_PLAZAS] = String.valueOf(entity.getPlazasSolicitadas());
        fields[COLUMN_FECHA_TIEMPO_REALIZACION] =  entity.getFechaRealizacionFormatted();
        return String.join(FIELD_SEPARATOR, fields);
    }

    @Override
    protected Reserva getEntityFromRegister(String register) {
        String[] reservaFields = register.split(FIELD_SEPARATOR);
        String codigoViajeReserva = reservaFields[COLUM_COD_RESERVA];
        String nombre = reservaFields[COLUMN_USUARIO];
        int plazasReservadas = Integer.parseInt(reservaFields[COLUMN_PLAZAS]);
        LocalDateTime fechaRealizacion = LocalDateTime.parse(reservaFields[COLUMN_FECHA_TIEMPO_REALIZACION], DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss"));
        return new Reserva(codigoViajeReserva, nombre, plazasReservadas, fechaRealizacion);
    }
}
