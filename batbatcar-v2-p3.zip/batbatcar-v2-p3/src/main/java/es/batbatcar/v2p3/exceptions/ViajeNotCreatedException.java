package es.batbatcar.v2p3.exceptions;

public class ViajeNotCreatedException extends RuntimeException {
    public ViajeNotCreatedException() {
        super("Modificar viaje es incorrecto");
    }
}
