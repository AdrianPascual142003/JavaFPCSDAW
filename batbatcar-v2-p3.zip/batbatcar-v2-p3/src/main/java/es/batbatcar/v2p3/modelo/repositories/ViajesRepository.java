package es.batbatcar.v2p3.modelo.repositories;

import es.batbatcar.v2p3.exceptions.ReservaNotFoundException;
import es.batbatcar.v2p3.exceptions.ViajeNotFoundException;
import es.batbatcar.v2p3.modelo.dao.IReservaDAO;
import es.batbatcar.v2p3.modelo.dao.IViajeDAO;
import es.batbatcar.v2p3.modelo.dao.impl.FileReservaDAO;
import es.batbatcar.v2p3.modelo.dao.impl.FileViajeDAO;
import es.batbatcar.v2p3.modelo.dao.impl.SQLReservaDAO;
import es.batbatcar.v2p3.modelo.dao.impl.SQLViajeDAO;
import es.batbatcar.v2p3.modelo.dto.Reserva;
import es.batbatcar.v2p3.modelo.dto.types.Viaje;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Service
public class ViajesRepository {

    private final IViajeDAO viajeDAO;

    private final IReservaDAO reservaDAO;

    @Autowired
    public ViajesRepository(SQLViajeDAO viajeDAO, SQLReservaDAO reservaDAO) {
        this.viajeDAO = viajeDAO;
        this.reservaDAO = reservaDAO;
    }
    public boolean saveWithReservas(Viaje viaje) {
        ArrayList<Reserva> reservasActuales = viaje.getReservas();
        ArrayList<Reserva> reservasOld = this.reservaDAO.findByTravel(viaje.getId());
        reservasOld.removeAll(reservasActuales);
        for (Reserva reserva: reservasOld) {
            reservaDAO.remove(reserva);
        }
        reservasActuales.removeAll(reservasOld);
        for (Reserva reserva: reservasActuales) {
            reservaDAO.save(reserva);
        }
        return viajeDAO.save(viaje);
    }

    public boolean save(Viaje viaje) {
       return viajeDAO.save(viaje);
    }

    public int getNextCod() {
        return countViajes() + 1;
    }

    public Viaje findViaje(int codViaje) {
        Viaje viaje = this.viajeDAO.findById(codViaje);
        if (viaje == null) {
            return viaje;
        }
        viaje.setReservas(this.reservaDAO.findByTravel(String.valueOf(codViaje)));
        return viaje;
    }

    public Set<Viaje> getAll(Class<? extends Viaje> viajeClass) {
        Set<Viaje> viajes = viajeDAO.findAll(viajeClass);
        if (viajes.isEmpty()) {
            return viajes;
        }
        for (Viaje viaje: viajes) {
            viaje.setReservas(this.reservaDAO.findByTravel(String.valueOf(viaje.getCodViaje())));
        }
        return viajes;
    }

    public Viaje getViaje(int codViaje) throws ViajeNotFoundException {
        Viaje viaje = findViaje(codViaje);
        if (viaje == null){
            throw new ViajeNotFoundException(codViaje);
        }
        return viaje;
    }

    public Viaje getViaje(int codViaje, String destino) throws ViajeNotFoundException {
        Viaje viaje = viajeDAO.getById(codViaje);
        if (!viaje.tieneEsteCiudadDestino(destino)) {
            throw new ViajeNotFoundException("No existe un viaje con cod " + codViaje + " y destino " + destino);
        }
        viaje.setReservas(reservaDAO.findByTravel(String.valueOf(codViaje)));
        return viaje;
    }

    public Viaje getViajeConReserva(String codReserva) throws ReservaNotFoundException {
        String[] codViajeYcodReserva = codReserva.split("-");
        int codViaje = Integer.parseInt(codViajeYcodReserva[0]);
        reservaDAO.getById(codReserva);
        return findViaje(codViaje);
    }

    public Set<Viaje> getViajeConDestino(String destino) throws ViajeNotFoundException{
        Set<Viaje> viajes = viajeDAO.findAll(destino);
        if (viajes == null) {
            throw new ViajeNotFoundException("No se han encontrado viajes");
        }
        for (Viaje viaje: viajes) {
            viaje.setReservas(reservaDAO.findByTravel(String.valueOf(viaje.getCodViaje())));
        }
        return viajes;
    }


    public Set<Viaje> findAll() {
        Set<Viaje> viajes = viajeDAO.findAll();
        setReservasAViajes(viajes);
        return viajes;
    }

    private void setReservasAViajes(Set<Viaje> viajes) {
        for (Viaje viaje : viajes) {
            viaje.setReservas(this.reservaDAO.findByTravel(String.valueOf(viaje.getCodViaje())));
        }
    }

    private int countViajes() {
        return this.viajeDAO.findAll().size();
    }
}
