package es.batbatcar.v2p3.controllers;
import es.batbatcar.v2p3.exceptions.ViajeNotCancelableException;
import es.batbatcar.v2p3.exceptions.ViajeNotFoundException;
import es.batbatcar.v2p3.modelo.dto.Reserva;
import es.batbatcar.v2p3.modelo.dto.types.*;
import es.batbatcar.v2p3.modelo.repositories.ViajesRepository;
import es.batbatcar.v2p3.utils.Validator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Controller
public class ViajesController {

    @Autowired
    private ViajesRepository viajesRepository;

    /**
     * Endpoint que muestra el listado de todos los viajes disponibles
     *
     * */
    @GetMapping("viajes")
    public String getViajesAction(Model modelFromView) {
        modelFromView.addAttribute("viajes", viajesRepository.findAll());
        modelFromView.addAttribute("titulo", "Listado de viajes");
        return "viaje/listado";
    }

    /**
     * EndPoint que muestra toda la información detallada del viaje @codViaje
     *
     * @param codViaje
     */
    @GetMapping("viaje")
    public String getViajesAction(@RequestParam int codViaje, Model modelFromView) {
        try {
            Viaje viaje = viajesRepository.getViaje(codViaje);
            List<Reserva> reservas = viaje.getReservas();
            modelFromView.addAttribute("viaje", viaje);
            modelFromView.addAttribute("tiposViajes", getTiposViajeValidos());
            modelFromView.addAttribute("titulo", "Detalle Viaje " + codViaje);
            modelFromView.addAttribute("editable", false);
            modelFromView.addAttribute("reservas", reservas);
            return "viaje/viaje_detalle";
        } catch (ViajeNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    @GetMapping("viajes/cancelados")
    public String getViajesCancelables(Model model) {
        Set<Viaje> viajes = viajesRepository.findAll();
        Set<Viaje> viajesCancelados = new HashSet<>();
        for (Viaje viaje: viajes) {
            if (viaje.isCancelado()) {
                viajesCancelados.add(viaje);
            }
        }
        model.addAttribute("viajes", viajesCancelados);
        return "viaje/listado";
    }

    @GetMapping("viajes/search")
    public String getViajesSearchDestination(@RequestParam Map<String, String> params, Model model) throws ViajeNotFoundException {
        String ciudad = params.get("search");
       Set<Viaje> viajes = viajesRepository.getViajeConDestino(ciudad);
       model.addAttribute("viajes", viajes);
       return "viaje/listado";
    }

    @PostMapping("/viaje/cancelar")
    public String postViajesActionCancelar(@RequestParam int codViaje) throws ViajeNotFoundException, ViajeNotCancelableException {
        Viaje viaje = viajesRepository.getViaje(codViaje);
        viaje.cancelar();
        viajesRepository.save(viaje);
        return "redirect:/viajes";
    }

    /**
     * EndPoint que muestra el formulario para dar de alta un viaje
     */
    @GetMapping("viaje/add")
    public String getViajesFormAction(Model modelFromView) {
        modelFromView.addAttribute("tiposViajes", getTiposViajeValidos());
        modelFromView.addAttribute("titulo", "Añadir Viaje");
        return "viaje/viaje_form";
    }

    /**
     * EndPoint que procesa los datos del formulario para dar de alta un viaje
     */
    @PostMapping("viaje/add")
    public String postViajesFormAction(@RequestParam HashMap<String, String> formParams,
                                       RedirectAttributes redirectAttributes) {
        String ruta = formParams.get("ruta");
        String tipoViaje = formParams.get("tipoViaje");
        String plazasOfertadas = formParams.get("plazasOfertadas");
        String propietario = formParams.get("propietario");
        String precio = formParams.get("precio");
        String duracion = formParams.get("duracion");
        String fechaSalida = formParams.get("fecha_salida");
        String tiempoSalida = formParams.get("tiempo_salida");
        HashMap<String, String> errors = new HashMap<>();
        if (ruta == null || !Validator.isValidRoute(ruta)){
            errors.put("ruta", "Debe cumplir el patron ciudad1-ciudad2-...");
        }
        System.out.println(tipoViaje);
        System.out.println(Arrays.binarySearch(getTiposViajeValidos(), tipoViaje));
        if (tipoViaje == null || Arrays.binarySearch(getTiposViajeValidos(), tipoViaje) < 0){
            errors.put("tipoViaje", "Debe ser un valor válido");
        }
        if (plazasOfertadas == null || !Validator.isNumeric(plazasOfertadas)){
            errors.put("plazasOfertadas", "Debe ser un valor númerico");
        }
        if (propietario == null){
            errors.put("propietario", "Campo requerido");
        }
        if (precio == null || !Validator.isNumeric(precio)){
            errors.put("precio", "Debe ser un valor numérico");
        }
        if (duracion == null || !Validator.isNumeric(duracion)){
            errors.put("duracion", "Debe ser un valor numérico");
        }
        String fechaYTiempoSalidaString = fechaSalida + " " + tiempoSalida;
        if (!Validator.isValidDateTime(fechaYTiempoSalidaString)) {
            errors.put("fechaSalida", "Debe ser una fecha válida");
        }
        if (errors.size() > 0) {
            redirectAttributes.addFlashAttribute("errors", errors);
            return "redirect:/viaje/add";
        }
        LocalDateTime fechaYTiempoSalida = LocalDateTime.parse(fechaYTiempoSalidaString, DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm"));
        Viaje viaje;
        int codViaje = viajesRepository.getNextCod();
        switch (tipoViaje) {
            case "Viaje":
                viaje = new Viaje(codViaje, propietario, ruta, fechaYTiempoSalida, Integer.parseInt(duracion),
                        Float.parseFloat(precio), Integer.parseInt(plazasOfertadas));
                break;
            case "Viaje Cancelable":
                viaje = new ViajeCancelable(codViaje, propietario, ruta, fechaYTiempoSalida, Integer.parseInt(duracion),
                        Float.parseFloat(precio), Integer.parseInt(plazasOfertadas));
                break;
            case "Viaje Exclusivo":
                viaje = new ViajeExclusivo(codViaje, propietario, ruta, fechaYTiempoSalida, Integer.parseInt(duracion),
                        Float.parseFloat(precio), Integer.parseInt(plazasOfertadas));
                break;
            default:
                viaje = new ViajeFlexible(codViaje, propietario, ruta, fechaYTiempoSalida, Integer.parseInt(duracion),
                        Float.parseFloat(precio), Integer.parseInt(plazasOfertadas));
                break;
        }
        viajesRepository.save(viaje);
        return "redirect:/viajes";
    }

    private String[] getTiposViajeValidos() {
        return new String[] {"Viaje", "Viaje Cancelable", "Viaje Exclusivo", "Viaje Flexible"};
    }

}
