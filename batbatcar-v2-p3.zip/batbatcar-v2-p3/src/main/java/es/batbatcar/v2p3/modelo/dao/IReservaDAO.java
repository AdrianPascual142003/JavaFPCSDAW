package es.batbatcar.v2p3.modelo.dao;

import es.batbatcar.v2p3.exceptions.ReservaNotFoundException;
import es.batbatcar.v2p3.modelo.dto.Reserva;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public interface IReservaDAO {

    /**
     * Obtiene un set con todas las reservas de la base de datos
     *
     * @return Set
     */
    Set<Reserva> findAll();

    /**
     * Busca una Reserva con el codigo @id
     *
     * @param id
     * @return Reserva o null si no existe la reserva en la bd
     */
    Reserva findById(String id);

    /**
     * Obtiene la reserva cuyo código es @id
     * @param id
     *
     * @return Reserva
     *
     * @throws ReservaNotFoundException si la reserva con @id no se encuentra
     */
    Reserva getById(String id) throws ReservaNotFoundException;

    /**
     * Obtiene un listado de todas las reservas realizadas por un @user
     *
     * @param user
     * @return Array List de reservas del usuario
     */
    ArrayList<Reserva> findByUser(String user);

    /**
     * Obtiene un listado de todas las reservas de un viaje
     *
     * @param codViaje
     * @return Array List de reservas
     */
    ArrayList<Reserva> findByTravel(String codViaje);

    /**
     * Guarda una reserva en la base de datos. Si la reserva No existe se crea una nuevoa.
     * Si la reserva ya existe se actualizan sus campos
     *
     * @param reserva
     * @return bool indica si la reserva se ha insertado/actualizado con éxito
     */
    boolean save(Reserva reserva);

    /**
     * Elimina la reserva de la Base datos
     *
     * @param reserva
     * @return boolean indica si la reserva ha sido eliminada
     */
    boolean remove(Reserva reserva);

    /**
     * Retorna todas las reservas cuyo nombre de usuario o codigo contenga la cadena contenida en @searchParams
     *
     * @param codViaje
     * @param searchParams
     *
     * @return List<Reserva>
     */
    List<Reserva> findBySearchParams(String codViaje, String searchParams);

}
