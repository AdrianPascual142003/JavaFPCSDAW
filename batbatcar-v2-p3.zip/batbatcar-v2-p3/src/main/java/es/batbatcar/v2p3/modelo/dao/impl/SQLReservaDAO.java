package es.batbatcar.v2p3.modelo.dao.impl;

import es.batbatcar.v2p3.exceptions.DatabaseConnectionException;
import es.batbatcar.v2p3.exceptions.ReservaNoValidaException;
import es.batbatcar.v2p3.exceptions.ReservaNotFoundException;
import es.batbatcar.v2p3.modelo.dao.IReservaDAO;
import es.batbatcar.v2p3.modelo.dto.Reserva;
import es.batbatcar.v2p3.modelo.dto.types.Viaje;
import es.batbatcar.v2p3.utils.database.MySQLConnection;
import org.apache.tomcat.jni.Local;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

@Service
public class SQLReservaDAO implements IReservaDAO {

    private final MySQLConnection mySQLConnection;

    public SQLReservaDAO(@Autowired MySQLConnection mySQLConnection) {
        this.mySQLConnection = mySQLConnection;
    }
    @Override
    public Set<Reserva> findAll() {
        Connection connection = mySQLConnection.getConnection();
        Set<Reserva> reservas = new HashSet<>();
        String sql = "SELECT * from reservas";
        try(PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            ResultSet rs = preparedStatement.executeQuery();
            while (rs.next()) {
                reservas.add(mapToEntity(rs));
            }
            return reservas;
        } catch (SQLException e) {
            throw new RuntimeException();
        }
    }

    @Override
    public Reserva findById(String id) {
        Connection connection = mySQLConnection.getConnection();
        String sql = "SELECT * from reservas where codigoReserva like ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1,id);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return mapToEntity(rs);
            }
            return null;
        } catch (SQLException e) {
            throw new DatabaseConnectionException(e.getMessage());
        }
    }

    @Override
    public ArrayList<Reserva> findByUser(String user) {
        Connection connection = mySQLConnection.getConnection();
        ArrayList<Reserva> reservas = new ArrayList<>();
        String sql = "SELECT * from reservas where usuario like ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, user);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                reservas.add(mapToEntity(rs));
            }
            return reservas;
        } catch (SQLException e) {
            throw new DatabaseConnectionException(e.getMessage());
        }
    }

    @Override
    public ArrayList<Reserva> findByTravel(String codViaje) {
        Connection connection = mySQLConnection.getConnection();
        ArrayList<Reserva> reservas = new ArrayList<>();
        String sql = "SELECT * from reservas where viaje = ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setInt(1, Integer.parseInt(codViaje));
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                reservas.add(mapToEntity(rs));
            }
            return reservas;
        } catch (SQLException e) {
            throw new DatabaseConnectionException(e.getMessage());
        }
    }

    @Override
    public Reserva getById(String id) throws ReservaNotFoundException {
        Reserva reserva = findById(id);
        if (reserva == null) {
            throw new ReservaNotFoundException("No se ha encontrado las reserva");
        }
        return reserva;
    }

    @Override
    public boolean save(Reserva reserva) {
        if (findById(reserva.getCodigoReserva()) == null) {
            return insert(reserva);
        } else {
            return update(reserva);
        }
    }


    private boolean insert(Reserva reserva) {
        Connection connection = mySQLConnection.getConnection();
        String sql = "INSERT INTO reservas VALUES (?,?,?,?,?)";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, reserva.getCodigoReserva());
            ps.setString(2,reserva.getUsuario());
            ps.setInt(3,reserva.getPlazasSolicitadas());
            ps.setTimestamp(4, Timestamp.valueOf(reserva.getFechaRealizacion()));
            ps.setInt(5,reserva.getCodigoViaje());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            throw new DatabaseConnectionException(e.getMessage());
        }
    }

    private boolean update(Reserva reserva) {
        Connection connection = mySQLConnection.getConnection();
        String sql = "UPDATE reservas SET usuario = ?, plazasSolicitadas = ?, fechaRealizacion = ?, viaje = ? where codigoReserva like ?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1,reserva.getUsuario());
            ps.setInt(2,reserva.getPlazasSolicitadas());
            ps.setTimestamp(3, Timestamp.valueOf(reserva.getFechaRealizacion()));
            ps.setInt(4,reserva.getCodigoViaje());
            ps.setString(5, reserva.getCodigoReserva());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            throw new DatabaseConnectionException(e.getMessage());
        }
    }

    @Override
    public boolean remove(Reserva reserva) {
        Connection connection = mySQLConnection.getConnection();
        String sql = "DELETE FROM reservas where codigoReserva like ?" ;
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1,reserva.getCodigoReserva());
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            throw new DatabaseConnectionException(e.getMessage());
        }
    }

    @Override
    public List<Reserva> findBySearchParams(String codViaje, String searchParams) {
        return null;
    }

    public Reserva mapToEntity(ResultSet rs) throws SQLException {
        String codigoReserva = rs.getString("codigoReserva");
        String usuario = rs.getString("usuario");
        int plazasSolicitadas = rs.getInt("plazasSolicitadas");
        LocalDateTime fechaRealizacion = rs.getTimestamp("fechaRealizacion").toLocalDateTime();
        return new Reserva(codigoReserva,usuario,plazasSolicitadas,fechaRealizacion);
    }
}
